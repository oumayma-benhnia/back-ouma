package com.example.demo2.service;

import com.example.demo2.bean.DemandeDeclaration;
import com.example.demo2.bean.PaymentDeclaration;
import com.example.demo2.dao.PaymentDeclarationDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentDeclarationService {
    @Autowired
    private PaymentDeclarationDao paymentDeclarationDao;
    @Autowired
    private DemandeDeclarationService demandeDeclarationService;



    public int save(PaymentDeclaration paymentDeclaration){
        if (findByType(paymentDeclaration.getCode()) != null) {
            return -1;
        }
        DemandeDeclaration demandeDeclaration = demandeDeclarationService.findByRef(paymentDeclaration.getDemandeDeclaration().getRef());
        paymentDeclaration.setDemandeDeclaration(demandeDeclaration);
        if(demandeDeclaration==null){
            return -2;
        } else if (demandeDeclaration.getTotalPaye()+paymentDeclaration.getMontant()>demandeDeclaration.getTotal()) {
            return -3;
        }
        else {
            double nvtotalPaye = demandeDeclaration.getTotalPaye()+paymentDeclaration.getMontant();
            demandeDeclaration.setTotalPaye(nvtotalPaye);
            demandeDeclarationService.update(demandeDeclaration);
            paymentDeclarationDao.save(paymentDeclaration);
            return 1;
        }


    }

    public PaymentDeclaration findByType(String code) {
        return paymentDeclarationDao.findByCode(code);
    }

    public int deleteByType(String code) {
        return paymentDeclarationDao.deleteByCode(code);
    }

    public List<PaymentDeclaration> findAll() {
        return paymentDeclarationDao.findAll();
    }

}
