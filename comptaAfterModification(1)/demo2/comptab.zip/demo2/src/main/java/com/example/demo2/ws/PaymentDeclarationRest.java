package com.example.demo2.ws;

import com.example.demo2.bean.PaymentDeclaration;
import com.example.demo2.service.PaymentDeclarationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping
public class PaymentDeclarationRest {
    @Autowired
    private PaymentDeclarationService paymentDeclarationService;

    @PostMapping("/")
    public int save(PaymentDeclaration paymentDeclaration) {
        return paymentDeclarationService.save(paymentDeclaration);
    }
    @GetMapping("/code/{code}")
    public PaymentDeclaration findByType(String code) {
        return paymentDeclarationService.findByType(code);
    }
    @DeleteMapping("/code/{code}")
    public int deleteByType(String code) {
        return paymentDeclarationService.deleteByType(code);
    }
    @GetMapping("/")
    public List<PaymentDeclaration> findAll() {
        return paymentDeclarationService.findAll();
    }
}
